# -*- coding: utf-8 -*-
# Part of Kanak Infosystems LLP. See LICENSE file for full copyright and licensing details.

from . import sale_loyalty
from . import res_config
from . import res_company
from . import res_partner
from . import sale
from . import product
